# 📊 CI Integration of JMeter (Petc.jmx) with Jenkins – PetClinic Application

## 1. Overview

This document describes the Continuous Integration (CI) setup for executing **Apache JMeter performance tests** using the `Petc.jmx` test plan for the **Spring PetClinic application** through **Jenkins**.

The Jenkins pipeline is already configured and committed in the repository. On every pipeline run, Jenkins:
- Checks out the test code from Git
- Executes the JMeter test in **non-GUI mode**
- Generates an **HTML performance report**
- Archives the test results as **build artifacts**
- Publishes the HTML report in the Jenkins UI

---

## 2. Prerequisites

### 🛠 Required Tools
- Jenkins (installed and running on Windows)
- Apache JMeter **5.6.3**
- Java JDK **8 or higher**
- Git

### 🌐 Application Under Test
- **Spring PetClinic**
- Running locally at:
  http://localhost:8080


---

## 🔄 CI Execution Flow

1. Jenkins triggers the pipeline (manual or scheduled)
2. Repository is cloned from Git
3. JMeter test plan `Petc.jmx` is executed in **non-GUI mode**
4. Test results are saved in `.jtl` format
5. JMeter generates an **HTML dashboard report**
6. Jenkins archives the results as build artifacts
7. HTML performance report is published in Jenkins

---

## ⚙️ JMeter Test Execution Details

- **Execution Mode:** Non-GUI (CI-friendly)
- **Results File:** `JMeter.jtl`
- **HTML Report Directory:** `reports/HtmlReport`
- **Report Entry File:** `index.html`

### 📊 Metrics Available in HTML Report
- Throughput
- Response time (average, minimum, maximum, percentiles)
- Error percentage
- Active threads over time
- Response time vs load graphs

---

## 📦 Jenkins Artifacts and Reports

### 📁 Archived Artifacts
- JMeter result file (`.jtl`)
- Complete HTML report directory

### 🌐 Viewing HTML Report in Jenkins
1. Open the Jenkins job
2. Click on a specific **Build Number**
3. Select **JMeter Performance Report**
4. View the interactive HTML dashboard

---

## 📸 Screenshots to Capture (For Submission)

- Jenkins pipeline successful build
- Console output showing JMeter execution
- Archived artifacts section
- Published JMeter HTML report
- Key performance graphs (Throughput, Response Time, Errors)


