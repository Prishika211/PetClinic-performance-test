const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const lighthouse = require('lighthouse');

(async () => {
    try {
        console.log('🚀 Lighthouse Flow started');
        console.log('📂 Working directory:', process.cwd());

        const reportPath = path.join(__dirname, 'lighthouse-report.html');

        /* ---------- Launch Browser (CI Safe) ---------- */
        const browser = await puppeteer.launch({
            headless: 'new',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-gpu'
            ]
        });

        const page = await browser.newPage();
        await page.setViewport({ width: 1920, height: 1080 });

        /* ---------- Lighthouse Flow ---------- */
        const flow = await lighthouse.startFlow(page, {
            name: 'PetClinic User Journey',
            configContext: {
                settingsOverrides: {
                    onlyCategories: ['performance'],
                    formFactor: 'desktop'
                }
            }
        });

        const baseURL = 'http://localhost:8080/';

        /* ================= HOME PAGE ================= */
        await flow.navigate(baseURL, { stepName: 'Open Home Page' });

        /* ================= FIND OWNERS ================= */
        await page.waitForSelector("a[href='/owners/find']", { timeout: 30000 });

        await flow.navigate(async () => {
            await page.evaluate(() => {
                document.querySelector("a[href='/owners/find']").click();
            });
        }, { stepName: 'Open Find Owners Page' });

        /* ================= SUBMIT FIND OWNERS ================= */
        await page.waitForSelector("button[type='submit']", { timeout: 30000 });

        await flow.navigate(async () => {
            await page.evaluate(() => {
                document.querySelector("button[type='submit']").click();
            });
        }, { stepName: 'Submit Find Owners' });

        /* ================= OPEN OWNER ================= */
        await page.waitForSelector("a[href='/owners/1']", { timeout: 30000 });

        await flow.navigate(async () => {
            await page.evaluate(() => {
                document.querySelector("a[href='/owners/1']").click();
            });
        }, { stepName: 'Open Owner Details' });

        /* ================= ADD PET ================= */
        await page.waitForSelector("a[href='1/pets/new']", { timeout: 30000 });

        await flow.navigate(async () => {
            await page.evaluate(() => {
                document.querySelector("a[href='1/pets/new']").click();
            });
        }, { stepName: 'Open Add Pet Page' });

        /* ================= FILL PET FORM ================= */
        await page.waitForSelector('#name', { timeout: 30000 });

        await page.type('#name', 'JenkinsPet');
        await page.type('#birthDate', '2025-12-10');
        await page.select('#type', 'cat');

        /* ================= SUBMIT ADD PET ================= */
        await page.waitForSelector("button[type='submit']", { timeout: 30000 });

        await flow.navigate(async () => {
            await page.evaluate(() => {
                document.querySelector("button[type='submit']").click();
            });
        }, { stepName: 'Submit Add Pet' });

        /* ================= GENERATE REPORT ================= */
        const reportHtml = await flow.generateReport();
        fs.writeFileSync(reportPath, reportHtml);

        if (!fs.existsSync(reportPath)) {
            throw new Error('❌ Lighthouse report not generated');
        }

        console.log('✅ Lighthouse report generated:', reportPath);

        await browser.close();
        process.exit(0);

    } catch (error) {
        console.error('❌ Lighthouse execution failed');
        console.error(error);
        process.exit(1);
    }
})();
