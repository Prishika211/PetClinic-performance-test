# 🚦 Lighthouse CI Integration for PetClinic (Jenkins)

This document describes how **Google Lighthouse** performance testing is integrated into **Jenkins CI** using a custom Node.js script (`new.js`) for the **Spring PetClinic application**.

---

## 🌐 Application Under Test

**Spring PetClinic URL**
http://localhost:8080


> ⚠️ The PetClinic application must be **running and accessible** before triggering the Jenkins pipeline.

---

## 🔐 Jenkins Prerequisites

### 1. Jenkins Configuration
- Jenkins running on Windows agent
- Node.js installed on the Jenkins machine
- Git SSH credentials configured



### 2. Required Software on Jenkins Agent
- **Node.js (LTS recommended)**
- **npm**
- Chromium (bundled via Puppeteer)
- Running PetClinic application

Verify Node & npm:
```bash
node -v
npm -v


learningperformancetesting/
│
└── PetClinic-Lighthouse Reporting and CI Task/
    ├── new.js
    ├── package.json
    ├── package-lock.json
    ├── node_modules/
    └── lighthouse-report.html   (generated during CI run)

```
---
## 🔄 CI Execution Flow

1. Jenkins pipeline is triggered (manual or scheduled)
2. Repository is cloned from Git
3. Jenkins enters the **PetClinic-Lighthouse Reporting and CI Task** directory
4. `new.js` is executed using **Node.js**
5. Puppeteer launches **Chromium in headless mode**
6. Lighthouse **user-flow performance audit** is executed
7. Lighthouse HTML report is generated as:
   lighthouse-report.html
8. Jenkins archives the report as a **build artifact**
9. Jenkins publishes the HTML report for **easy viewing**

---

## ⚙️ Lighthouse Execution Details

- **Tool:** Google Lighthouse
- **Runner:** Puppeteer + Lighthouse User Flow
- **Execution Mode:** Headless (CI-friendly)
- **Categories Audited:** Performance
- **Form Factor:** Desktop
- **Output File:** `lighthouse-report.html`
- **Report Location:** Project root directory

---

## 📊 Metrics Available in Lighthouse Report

The generated Lighthouse HTML report includes:

- Performance score
- First Contentful Paint (FCP)
- Largest Contentful Paint (LCP)
- Total Blocking Time (TBT)
- Cumulative Layout Shift (CLS)
- Speed Index
- Diagnostic recommendations
- Opportunities for optimization

---

## 📦 Jenkins Artifacts and Reports

### 📁 Archived Artifacts
- `lighthouse-report.html`

### 🌐 Viewing Lighthouse Report in Jenkins
1. Open the Jenkins job
2. Select a specific **Build Number**
3. Click **Lighthouse Performance Report**
4. View the interactive Lighthouse dashboard directly in Jenkins

---

## 📸 Screenshots to Capture (For Submission)

- Jenkins pipeline successful build
- Console output showing `node new.js` execution
- Directory listing confirming `lighthouse-report.html`
- Archived artifacts section
- Published Lighthouse HTML report
- Performance score summary

---

## 🏁 Conclusion

The **Lighthouse–Jenkins CI integration** enables automated, repeatable, and reliable frontend performance testing for the **PetClinic application**.  
By running Lighthouse audits directly in Jenkins, performance metrics are continuously monitored, reports are centrally available, and UI performance regressions can be identified early in the development lifecycle.

---

