package simulations

import config.BaseHelpers.httpProtocol
import io.gatling.core.Predef._
import scenarios.PetClinicScenario

import scala.concurrent.duration.DurationInt
import scala.language.postfixOps

class PetClinicSimulation extends Simulation{
//  setUp(
//    PetClinicScenario.petClinicFlow.inject(
//          constantConcurrentUsers(400) during (10 minutes),
//      constantConcurrentUsers(800) during (10 minutes),
//      constantConcurrentUsers(1200) during (10 minutes),
//      constantConcurrentUsers(1600) during (10 minutes),
//      constantConcurrentUsers(2000) during (10 minutes),
//      constantConcurrentUsers(2400) during (10 minutes),
//      constantConcurrentUsers(2800) during (10 minutes),
//      constantConcurrentUsers(3000) during (10 minutes),
//  )).protocols(httpProtocol)

//  setUp(
//    PetClinicScenario.petClinicFlow.inject(
//      constantConcurrentUsers(2400) during (30 minutes),
//    )).protocols(httpProtocol)

//  setUp(
//    PetClinicScenario.petClinicFlow.inject(
//        constantConcurrentUsers(20) during (5 minutes),
//        constantConcurrentUsers(100) during (10.minutes),
//        constantConcurrentUsers(200) during (10.minutes),
//        constantConcurrentUsers(300) during (10.minutes),
//        constantConcurrentUsers(400) during (10.minutes),
//        constantConcurrentUsers(500) during (10.minutes),
//        constantConcurrentUsers(600) during (10.minutes),
//        constantConcurrentUsers(700) during (10.minutes),
//        constantConcurrentUsers(800) during (10.minutes),
//        constantConcurrentUsers(900) during (10.minutes),
//        constantConcurrentUsers(1000) during (15.minutes),
//        constantConcurrentUsers(2000) during (20.minutes),
//        constantConcurrentUsers(3000) during (20.minutes),
//        constantConcurrentUsers(3500) during (20.minutes),
//        constantConcurrentUsers(4000) during (20.minutes),
//        constantConcurrentUsers(4500) during (20.minutes),
//        constantConcurrentUsers(5000) during (20.minutes),
//        constantConcurrentUsers(850) during (20.minutes),
//        constantConcurrentUsers(900) during (20.minutes),
//        constantConcurrentUsers(950) during (20.minutes),
//        constantConcurrentUsers(1000) during (20.minutes),
//  )).protocols(httpProtocol)

    setUp(
      PetClinicScenario.petClinicFlow.inject(
        constantConcurrentUsers(3) during (10 minutes),
      )).protocols(httpProtocol)
}
