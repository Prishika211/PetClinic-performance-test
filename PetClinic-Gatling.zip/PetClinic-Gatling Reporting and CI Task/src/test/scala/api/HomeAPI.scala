package api

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object HomeAPI {

  val openHomepage = exec(
    http("Open Homepage")
      .get("/")
      .check(status.is(200))
  )

}

