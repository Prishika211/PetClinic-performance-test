package api

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object OwnersAPI {

  val findOwnersPage = exec(
    http("Find Owner Page")
      .get("/owners/find")
      .check(status.is(200))
  )

  val clickAddOwner = exec(
    http("Click Add Owner")
      .get("/owners/new")
      .check(status.is(200))
  )

  val addOwner = exec(
    http("Add Owner Submit")
      .post("/owners/new")
      .formParam("firstName", "${p_first}")
      .formParam("lastName", "${p_last}")
      .formParam("address", "${p_add}")
      .formParam("city", "${p_city}")
      .formParam("telephone", "${p_tel}")
      .check(status.in(200, 302))                      // PetClinic returns 302
      .check(header("Location").saveAs("redir"))  // Capture: /owners/XX
  )
    .exec { session =>
      val redirectUrl = session("redir").as[String]      // /owners/25
      val ownerId = redirectUrl.split("/").last.trim     // 25
      session.set("ownerId", ownerId)
  }


  val openOwnerDetails = exec(
    http("Open Owner Details")
      .get("/owners/${ownerId}")
      .check(status.is(200))
  )

  val searchOwner = exec(
    http("Search Owner")
      .get("/owners?lastName=${p_last}")
      .check(status.in(200, 302))
  )
}


