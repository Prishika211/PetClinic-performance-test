package api

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object PetsAPI {

  val clickAddPet = exec(
    http("Click Add Pet")
      .get("/owners/${ownerId}/pets/new")
      .check(status.is(200))
  )

  val addPetDetails = exec(
    http("Add Pet Details")
      .post("/owners/${ownerId}/pets/new")
      .formParam("name", "${p_petname}")
      .formParam("birthDate", "2017-01-01")   // static or random later
      .formParam("type", "${p_pettype}")
      .check(status.in(200, 302))
  )
}
