package scenarios

import api.{HomeAPI, OwnersAPI, PetsAPI}
import config.BaseHelpers.thinkTimer
import io.gatling.core.Predef._

object PetClinicScenario {

  // CSV Feeder
  val petFeeder = csv("feeders/Parameterfile.csv").circular

  val petClinicFlow = scenario("PetClinic Full User Journey")
    .feed(petFeeder)

    // Flow Steps
    .exec(HomeAPI.openHomepage)
    .exec(thinkTimer())
    .exec(OwnersAPI.findOwnersPage)
    .exec(thinkTimer())
    .exec(OwnersAPI.clickAddOwner)
    .exec(thinkTimer())
    .exec(OwnersAPI.addOwner)
    .exec(thinkTimer())
    .exec(PetsAPI.clickAddPet)
    .exec(thinkTimer())
    .exec(PetsAPI.addPetDetails)
    .exec(thinkTimer())
    .exec(OwnersAPI.openOwnerDetails)
    .exec(thinkTimer())
    .exec(OwnersAPI.searchOwner)
    .exec(thinkTimer())
}

