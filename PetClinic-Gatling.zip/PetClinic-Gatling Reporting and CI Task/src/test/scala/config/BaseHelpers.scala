package config

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

object BaseHelpers {
  val basePetClinic = "http://localhost:8080/"

  def thinkTimer(min: Int = 2, max: Int = 5): ChainBuilder = {
    pause(min, max)
  }

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(basePetClinic)
    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
    .acceptEncodingHeader("gzip, deflate, br")
    .acceptLanguageHeader("en-GB,en-US;q=0.9,en;q=0.8")
    .upgradeInsecureRequestsHeader("1")
    .userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0")
    .disableFollowRedirect
}
