# 🚀 Gatling CI Integration with Jenkins

This document describes how to integrate **Gatling performance tests** with **Jenkins CI** to automatically execute Gatling simulations and publish **HTML performance reports** as Jenkins build artifacts.

---

## 🧰 Tools & Technologies

- **Jenkins** (Declarative Pipeline)
- **Apache Maven**
- **Java JDK (8 / 11 / 17)**
- **Gatling (Maven plugin)**
- **Jenkins Gatling Plugin**
- **Jenkins HTML Publisher Plugin**
- **Git (SSH authentication)**


---

## 🔁 Gatling Test Scenario Overview

The Gatling simulation covers backend performance testing of the **Spring PetClinic application**, including:

- Home page access
- Owner search
- Owner details retrieval
- Add owner
- Add pet
- Navigation flows

The simulation is executed for:
- **Duration**: ~10 minutes
- **Load**: 3–5 virtual users  
  (as per task requirements)

---


---

## 🧰 Prerequisites

### Jenkins Setup
Ensure the following are already configured in Jenkins:

- Jenkins installed and running
- Jenkins agent running on **Windows** (uses `bat` command)
- Required plugins installed:
    - **Pipeline**
    - **Git**
    - **HTML Publisher**
    - **Gatling Plugin**
- JDK and Maven installed on the Jenkins node
- SSH access to the Git repository

---

## 🔐 Git & SSH Configuration

1. Generate an SSH key (if not already available)
2. Add the **public key** to your Git repository (GitLab / GitHub / EPAM Git)
3. Add the **private key** in Jenkins:
   - Go to **Jenkins Dashboard > Manage Jenkins > Manage Credentials**
   - Add a new SSH credential with the private key
4. Verify repository access using SSH

---
## ⚙️ Jenkins CI Execution Flow

1. Jenkins pipeline is triggered (manual or scheduled)
2. Source code is checked out using SSH credentials
3. Jenkins navigates to the Gatling project directory
4. Maven executes the Gatling tests
5. Gatling generates HTML performance reports
6. Jenkins archives the Gatling reports
7. Jenkins publishes the HTML report for easy access

---

## 🎯 Outcome

With this setup, every Jenkins run:
- Executes Gatling tests
- Stores performance evidence
- Publishes professional HTML reports

This enables **reliable, automated performance testing** as part of your CI pipeline.

---
